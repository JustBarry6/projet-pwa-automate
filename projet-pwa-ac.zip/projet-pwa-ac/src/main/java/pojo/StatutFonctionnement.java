package pojo;

public enum StatutFonctionnement {
	EN_SERVICE, HORS_SERVICE;
}
