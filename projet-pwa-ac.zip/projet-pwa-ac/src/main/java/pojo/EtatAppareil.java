package pojo;

public enum EtatAppareil {
	OK, ATTENTION, ERREUR, ALARME;
}
