package pojo;

public enum EtatMonnayeur {
	NORMAL, PLEIN, VIDE;
}
