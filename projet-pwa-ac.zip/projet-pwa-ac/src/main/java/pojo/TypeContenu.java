package pojo;

public enum TypeContenu {
	BOISSON_CHAUDE, BOISSON_FROIDE, ENCAS;
}
