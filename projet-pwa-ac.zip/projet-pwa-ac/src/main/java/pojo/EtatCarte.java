package pojo;

public enum EtatCarte {
	NORMAL, ERREUR;
}
